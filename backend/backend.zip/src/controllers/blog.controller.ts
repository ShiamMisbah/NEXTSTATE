import { Request, Response } from "express";
import Blog from "../models/Blog";
import { clerkClient, getAuth } from "@clerk/express";

// GET /api/blogs?page=1&limit=10
export const getBlogs = async (req: Request, res: Response) => {
  
  try {
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 10, 1);

    const skip = (page - 1) * limit;

    const [blogs, totalBlogs] = await Promise.all([
      Blog.find()
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),

      Blog.countDocuments(),
    ]);

    const totalPages = Math.ceil(totalBlogs / limit);

    return res.status(200).json({
      success: true,
      data: blogs,
      pagination: {
        currentPage: page,
        limit,
        totalBlogs,
        totalPages,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
      },
    });
  } catch (error) {
    console.error("Get blogs error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch blogs",
    });
  }
};

// GET /api/blogs/published?page=1&limit=10
export const getPublishedBlogs = async (req: Request, res: Response) => {  
  try {
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 10, 1);

    const skip = (page - 1) * limit;

    const filter = {
      published: true,
    };

    const [blogs, totalBlogs] = await Promise.all([
      Blog.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),

      Blog.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(totalBlogs / limit);

    return res.status(200).json({
      success: true,
      data: blogs,
      pagination: {
        currentPage: page,
        limit,
        totalBlogs,
        totalPages,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
      },
    });
  } catch (error) {
    console.error("Get published blogs error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch published blogs",
    });
  }
};

// GET /api/blogs/:id
export const getBlogById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const blog = await Blog.findById(id);

    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: blog,
    });
  } catch (error) {
    console.error("Get blog error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch blog",
    });
  }
};

// GET /api/blogs/slug/:slug
export const getBlogBySlug = async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;

    const blog = await Blog.findOneAndUpdate(
      { slug },
      { $inc: { views: 1 } },
      { new: true },
    );

    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: blog,
    });
  } catch (error) {
    console.error("Get blog by slug error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch blog",
    });
  }
};

// POST /api/blogs
export const createBlog = async (req: Request, res: Response) => {
  
  try {
    const {
      title,
      slug,
      excerpt,
      content,
      category,
      image,
      readTime,
      featured,
      published,
    } = req.body;

    // Clerk authenticated user
    const { userId } = getAuth(req)

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const user = await clerkClient.users.getUser(userId);

    if (!title || !excerpt || !content || !category) {
      return res.status(400).json({
        success: false,
        message: "Title, excerpt, content and category are required",
      });
    }

    
    
    // You can replace this with Clerk user information
    const author = user.fullName;

    if (!author) {
      return res.status(400).json({
        success: false,
        message: "Author is required",
      });
    }

    const blog = await Blog.create({
      title,
      slug,
      excerpt,
      content,
      category,
      image: image || "",
      author,
      authorId: userId,
      readTime: readTime || "5 min read",
      featured: Boolean(featured),
      published: published !== false,
    });

    return res.status(201).json({
      success: true,
      message: "Blog created successfully",
      data: blog,
    });
  } catch (error: any) {
    console.error("Create blog error:", error);

    // Duplicate slug
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "A blog with this slug already exists",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to create blog",
    });
  }
};

// PUT /api/blogs/:id
export const updateBlog = async (req: Request, res: Response) => {
  
  try {
    const { id } = req.params;

    const {
      title,
      slug,
      excerpt,
      content,
      category,
      image,
      readTime,
      featured,
      published,
    } = req.body;

    // Clerk authenticated user
    const { userId } = getAuth(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const blog = await Blog.findById(id);

    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found",
      });
    }

    // Update only fields that were actually provided
    if (title !== undefined) blog.title = title;
    if (slug !== undefined) blog.slug = slug;
    if (excerpt !== undefined) blog.excerpt = excerpt;
    if (content !== undefined) blog.content = content;
    if (category !== undefined) blog.category = category;
    if (image !== undefined) blog.image = image;
    if (readTime !== undefined) blog.readTime = readTime;

    if (featured !== undefined) {
      blog.featured = Boolean(featured);
    }

    if (published !== undefined) {
      blog.published = Boolean(published);
    }

    // Only change author when you are intentionally attributing
    // the update to the current Clerk user.
    const user = await clerkClient.users.getUser(userId);

    const author = user.fullName;

    if (author) {
      blog.author = author;
      blog.authorId = userId;
    }

    const updatedBlog = await blog.save();

    return res.status(200).json({
      success: true,
      message: "Blog updated successfully",
      data: updatedBlog,
    });
  } catch (error: any) {
    console.error("Update blog error:", error);

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "A blog with this slug already exists",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to update blog",
    });
  }
};

// DELETE /api/blogs/:id
export const deleteBlog = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const blog = await Blog.findById(id);

    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found",
      });
    }

    await blog.deleteOne();

    return res.status(200).json({
      success: true,
      message: "Blog deleted successfully",
    });
  } catch (error) {
    console.error("Delete blog error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete blog",
    });
  }
};
